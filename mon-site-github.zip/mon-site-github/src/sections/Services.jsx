import React from 'react';
import { services } from '../data/services';

const Services = () => {
    return (
        <section id="services" className="section bg-light">
            <div className="container">
                <div className="section-header text-center">
                    <h2 className="section-title">Mes Soins</h2>
                    <p className="section-subtitle">Découvrez ma gamme complète de prestations pour votre bien-être.</p>
                </div>

                <div className="services-grid">
                    {services.map((category, index) => (
                        <div key={index} className={`service-category ${category.isSubscription ? 'service-category-subscription' : ''}`}>
                            <h3 className="category-title">{category.category}</h3>
                            {category.note && <p className="category-note">{category.note}</p>}
                            {category.description && <p className="category-description">{category.description}</p>}
                            <div className="service-list">
                                {category.items.map((item, i) => (
                                    <div key={i} className={`service-item ${item.highlight ? 'service-item-highlight' : ''}`}>
                                        <div className="service-info">
                                            <div className="service-name-wrapper">
                                                <span className="service-name">{item.name}</span>
                                                {item.badge && <span className="service-badge">{item.badge}</span>}
                                            </div>
                                            {item.duration && <span className="service-duration">{item.duration}</span>}
                                            {item.description && <p className="service-description">{item.description}</p>}
                                        </div>
                                        <div className="service-price">
                                            {item.originalPrice && <span className="service-price-old">{item.originalPrice} €</span>}
                                            <span className="service-price-current">{item.price} €</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Services;
