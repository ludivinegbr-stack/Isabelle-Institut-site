import React from 'react';
import { Star } from 'lucide-react';

const testimonials = [
    {
        name: "Carine Ollivier",
        text: "J'ai passé un très agréable moment avec Isabelle! C'était un cadeau pour mon anniversaire 🥳 Je vous recommande vivement cette dame aux doigts de fée 🧚",
        rating: 5
    },
    {
        name: "Fabienne LECOT",
        text: "Moment formidable.. avec Isabelle esthéticienne à Gouaix.. je vais y retourner avec plaisir",
        rating: 5
    },
    {
        name: "Dany Dernois",
        text: "Depuis 15 ans que je vais chez Isabelle Institut c'est toujours aussi bien je dirais que c'est de mieux en mieux j'aime beaucoup sa façon de travailler.",
        rating: 5
    },
    {
        name: "Yamina Marteau",
        text: "Aimable, Gentillesse et très agréable.",
        rating: 5
    },
    {
        name: "Flochupetta",
        text: "Top !",
        rating: 5
    },
    {
        name: "ludivine",
        text: "Esthéticienne très gentille et agréable, c’est toujours un plaisir d’y aller!😊\nL’accueil est vraiment chaleureux, on se sent tout de suite à l’aise.\nLes soins sont toujours super bien réalisés, avec douceur et professionnalisme, et on ressort à chaque fois détendue et contente du résultat.\nJe recommande fortement✨",
        rating: 5
    },
    {
        name: "florence",
        text: "Si vous recherchez un grand moment de détente et de soins, n'hésitez pas à aller voir isabelle institut, par sa grande experience acquise tout au long des années, elle permet à chacune de trouver le soin qui lui correspond. Ses massages (dos et visage) sont incroyables ! Foncez !💆🏻‍♀️✨",
        rating: 5
    },
    {
        name: "sophie",
        text: "J'ai beaucoup apprécié l'accueil et les soins d'isabelle institut, elle est charmante et très à l'écoute. Ses soins, notamment le kobido sont bluffants ! 🩷",
        rating: 5
    }
];

// Double the list for seamless infinite scroll
const scrollList = [...testimonials, ...testimonials];

const Testimonials = () => {
    return (
        <section id="testimonials" className="section bg-white overflow-hidden">
            <div className="container">
                <div className="section-header text-center">
                    <h2 className="section-title">Avis Clients</h2>
                    <p className="section-subtitle">Ce que disent mes clientes</p>
                </div>
            </div>

            <div className="scrolling-wrapper">
                <div className="scrolling-container">
                    {scrollList.map((item, index) => (
                        <div key={index} className="testimonial-bubble">
                            <div className="stars">
                                {[...Array(item.rating)].map((_, i) => (
                                    <Star key={i} size={14} fill="#B89F91" color="#B89F91" />
                                ))}
                            </div>
                            <p className="testimonial-text">"{item.text}"</p>
                            <h4 className="testimonial-name">{item.name}</h4>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Testimonials;
