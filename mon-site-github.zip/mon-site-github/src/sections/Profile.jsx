import React from 'react';

const Profile = () => {
    return (
        <section id="profile" className="profile-section">
            <div className="container">
                <div className="profile-grid">
                    <div className="profile-image-container">
                        <img src="/isabelle.jpg" alt="Isabelle - Facialiste" className="profile-img" />
                        <div className="profile-img-accent"></div>
                    </div>
                    <div className="profile-content">
                        <span className="profile-subtitle">L'âme de l'institut</span>
                        <h2 className="profile-title">Qui suis-je ?</h2>
                        <div className="profile-text">
                            <p>
                                Depuis 24 ans, ma passion pour l'esthétique ne m'a jamais quittée.
                                Au fil de mon parcours, j'ai développé une véritable expertise dans les soins et massages du visage,
                                jusqu’à me spécialiser en tant que <strong>facialiste</strong>.
                            </p>
                            <p>
                                Ce qui m'anime au quotidien, c'est de vous accueillir avec chaleur et bienveillance,
                                de comprendre votre peau et de vous offrir bien plus qu'un soin :
                                un moment pour vous reconnecter à vous-même.
                            </p>
                            <p>
                                À travers chaque geste, j'apporte une profonde détente, un véritable lâcher-prise,
                                qui se lit sur votre visage dès la fin du soin. Les traits sont apaisés,
                                l'éclat revient — et vous repartez aussi bien dans votre peau que dans votre esprit.
                            </p>
                            <p>
                                Je n'ai pas pour autant abandonné les autres prestations qui font partie de mon métier,
                                notamment les épilations réalisées en douceur, avec la même attention et le même respect de votre peau.
                            </p>
                        </div>
                        <div className="profile-signature">
                            <span className="signature-name">Isabelle</span>
                            <span className="signature-title">Votre Facialiste & Esthéticienne</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Profile;
