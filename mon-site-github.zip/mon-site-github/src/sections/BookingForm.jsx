import React, { useState } from 'react';
import { services } from '../data/services';

const BookingForm = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        treatment: '',
        message: ''
    });
    const [submitted, setSubmitted] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Flatten services for the dropdown
    const allTreatments = services.flatMap(cat => cat.items.map(item => item.name));

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);

        try {
            const response = await fetch("https://formsubmit.co/ajax/isabelle.institut77@gmail.com", {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    _subject: `Nouvelle demande de RDV : ${formData.name}`,
                    Nom: formData.name,
                    Email: formData.email,
                    Téléphone: formData.phone,
                    Soin: formData.treatment,
                    Message: formData.message || "Aucun message spécifique."
                })
            });

            if (response.ok) {
                setSubmitted(true);
            } else {
                alert("Une erreur est survenue lors de l'envoi. Veuillez me contacter directement par téléphone.");
            }
        } catch (error) {
            console.error('Erreur:', error);
            alert("Une erreur est survenue lors de l'envoi. Veuillez me contacter directement par téléphone.");
        } finally {
            setIsSubmitting(false);
        }
    };

    if (submitted) {
        return (
            <section id="booking" className="section">
                <div className="container text-center">
                    <div className="confirmation-card">
                        <h2 className="section-title">Merci {formData.name} !</h2>
                        <p>Votre demande de rendez-vous pour <strong>{formData.treatment}</strong> a bien été envoyée.</p>
                        <p>Isabelle vous recontactera très prochainement à l'adresse <strong>{formData.email}</strong> pour confirmer la date.</p>
                        <button className="btn btn-primary" style={{ marginTop: '2rem' }} onClick={() => setSubmitted(false)}>
                            Envoyer une autre demande
                        </button>
                    </div>
                </div>
            </section>
        );
    }

    return (
        <section id="booking" className="section">
            <div className="container">
                <div className="booking-grid">
                    <div className="booking-info">
                        <h2 className="section-title" style={{ marginBottom: '3rem' }}>Prendre Rendez-vous</h2>
                        <p className="mb-4">
                            Remplissez le formulaire ci-dessous pour demander un rendez-vous.
                            Indiquez-moi vos disponibilités dans le message, je vous répondrai par mail pour confirmer l'horaire.
                        </p>
                        <div className="contact-details">
                            <p><strong>Téléphone :</strong> 06.70.59.71.98</p>
                            <p><strong>Email :</strong> isabelle.institut77@gmail.com</p>
                            <div className="addresses-list" style={{ marginTop: '0.5rem' }}>
                                <p style={{ marginBottom: '0.5rem' }}><strong>Mes Adresses :</strong></p>
                                <p style={{ marginBottom: '0.5rem' }}>📍 <strong>Gouaix :</strong> 12 grande rue, 77114 (Du mardi au vendredi)</p>
                                <p>📍 <strong>Provins :</strong> 6 bis route de bray, 77160 (Le samedi exclusivement)</p>
                            </div>
                        </div>
                    </div>

                    <form className="booking-form" onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label htmlFor="name">Nom Complet</label>
                            <input
                                type="text"
                                id="name"
                                name="name"
                                required
                                placeholder="Votre nom"
                                value={formData.name}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="form-row">
                            <div className="form-group">
                                <label htmlFor="email">Email</label>
                                <input
                                    type="email"
                                    id="email"
                                    name="email"
                                    required
                                    placeholder="votre@email.com"
                                    value={formData.email}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="phone">Téléphone</label>
                                <input
                                    type="tel"
                                    id="phone"
                                    name="phone"
                                    required
                                    placeholder="06 12 34 56 78"
                                    value={formData.phone}
                                    onChange={handleChange}
                                />
                            </div>
                        </div>

                        <div className="form-group">
                            <label htmlFor="treatment">Soin souhaité</label>
                            <select
                                id="treatment"
                                name="treatment"
                                required
                                value={formData.treatment}
                                onChange={handleChange}
                            >
                                <option value="">Sélectionnez un soin</option>
                                {allTreatments.map((t, index) => (
                                    <option key={index} value={t}>{t}</option>
                                ))}
                            </select>
                        </div>

                        <div className="form-group">
                            <label htmlFor="message">Message (Disponibilités, questions...)</label>
                            <textarea
                                id="message"
                                name="message"
                                rows="4"
                                placeholder="Ex: Je suis disponible les mardis après-midi..."
                                value={formData.message}
                                onChange={handleChange}
                            ></textarea>
                        </div>

                        <button type="submit" className="btn btn-primary btn-block" disabled={isSubmitting}>
                            {isSubmitting ? "Envoi en cours..." : "Envoyer la demande"}
                        </button>
                    </form>
                </div>
            </div>
        </section>
    );
};

export default BookingForm;
