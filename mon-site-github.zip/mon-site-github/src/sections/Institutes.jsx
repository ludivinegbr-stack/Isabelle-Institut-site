import React from 'react';

const Institutes = () => {
    const locations = [
        {
            name: "Isabelle Institut - Gouaix",
            address: "12 grande rue, 77114 Gouaix",
            schedule: "Du Mardi au Vendredi",
            image: "/gouaix-room.jpg",
            note: "Votre escale beauté principale du mardi au vendredi."
        },
        {
            name: "Isabelle Institut - Provins",
            address: "6 bis route de bray, 77160 Provins",
            schedule: "Le Samedi exclusivement",
            image: "/provins.jpg",
            note: "Retrouvez-moi au cœur de Provins chaque samedi."
        }
    ];

    return (
        <section id="institutes" className="section bg-light">
            <div className="container">
                <div className="section-header text-center">
                    <h2 className="section-title">Mes Instituts</h2>
                    <p className="section-subtitle">À Gouaix comme à Provins, profitez de deux adresses dédiées à votre bien-être, dans des environnements calmes et ressourçants.</p>
                </div>

                <div className="institutes-grid">
                    {locations.map((loc, index) => (
                        <div key={index} className="institute-card">
                            <div className="institute-image">
                                <img src={loc.image} alt={loc.name} />
                                <div className="institute-tag">{loc.schedule}</div>
                            </div>
                            <div className="institute-info">
                                <h3>{loc.name}</h3>
                                <p className="institute-address">{loc.address}</p>
                                <p className="institute-note">{loc.note}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Institutes;
