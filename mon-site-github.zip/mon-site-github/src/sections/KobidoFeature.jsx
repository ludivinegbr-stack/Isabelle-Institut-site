import React from 'react';

const KobidoFeature = () => {
    return (
        <section id="kobido-highlight" className="section bg-warm">
            <div className="container">
                <div className="kobido-grid">
                    <div className="kobido-image-wrapper">
                        <img src="/kobido-new.jpeg" alt="KOBIDO Massage" className="kobido-image" style={{ objectFit: 'cover' }} />
                        <div className="kobido-badge">Nouveauté Exclusive</div>
                    </div>
                    <div className="kobido-content">
                        <h2 className="section-title">Le soin KOBIDO</h2>
                        <h3 className="kobido-subtitle">Le Lifting Manuel Japonais</h3>
                        <p className="kobido-description">
                            Véritable lifting naturel ancestral, le massage KOBIDO est bien plus qu'un simple soin du visage.
                            Par une gestuelle précise et rythmée, il stimule la circulation, raffermit les tissus et libère les tensions musculaires.
                            À la fin de la séance, vos traits sont lissés, votre peau est repulpée et votre teint retrouve un éclat incomparable.
                        </p>

                        <div className="kobido-offers">
                            <h4 className="offers-title">Cure Jeunesse & Éclat</h4>
                            <ul className="offers-list">
                                <li>
                                    <span className="offer-name">4 séances + 1 offerte (1h)</span>
                                    <span className="offer-price">320 €</span>
                                </li>
                                <li>
                                    <span className="offer-name">4 séances + 1 offerte (45min)</span>
                                    <span className="offer-price">280 €</span>
                                </li>
                            </ul>
                            <p className="offers-note">* Recommandé pour des résultats durables et profonds.</p>
                        </div>

                        <div className="kobido-action">
                            <a href="#booking" className="btn btn-primary">Réserver mon rituel</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default KobidoFeature;
