import React from 'react';
import { PenTool, Laptop, Calendar } from 'lucide-react';

const Services = () => {
    const services = [
        {
            title: "Mariage & Événements Privés",
            icon: <Calendar size={48} />,
            description: "Pour le plus beau jour de votre vie, je crée une identité visuelle unique et romantique.",
            items: [
                "Faire-part & Save the Date",
                "Invitations",
                "Menus & Marque-places",
                "Plans de table",
                "Panneaux de bienvenue",
                "Remerciements"
            ]
        },
        {
            title: "Communication Print",
            icon: <PenTool size={48} />,
            description: "Des supports imprimés professionnels pour promouvoir votre activité ou votre événement.",
            items: [
                "Flyers & Dépliants",
                "Brochures commerciales",
                "Affiches",
                "Cartes de visite",
                "Roll-ups",
                "Papeterie d'entreprise"
            ]
        },
        {
            title: "Web & Digital",
            icon: <Laptop size={48} />,
            description: "Votre présence en ligne avec un site web moderne et adapté à vos besoins.",
            items: [
                "Site vitrine (One page ou multi-pages)",
                "Design responsive (Mobile friendly)",
                "Visuels pour réseaux sociaux",
                "Bannières web",
                "Signature mail",
                "Maintenance & Mise à jour"
            ]
        }
    ];

    return (
        <div className="animate-fade-in section">
            <div className="container">
                <h1 className="text-center mb-4">Mes Prestations</h1>
                <p className="text-center mb-8" style={{ maxWidth: '700px', margin: '0 auto 4rem', color: '#666' }}>
                    Découvrez une gamme complète de services pour sublimer votre communication, du papier au digital.
                </p>

                <div className="grid grid-3">
                    {services.map((service, index) => (
                        <div key={index} className="card">
                            <div className="service-icon">{service.icon}</div>
                            <h2 className="text-center mb-4">{service.title}</h2>
                            <p className="text-center mb-6" style={{ fontSize: '0.95rem', color: '#666' }}>{service.description}</p>
                            <ul className="service-list">
                                {service.items.map((item, idx) => (
                                    <li key={idx}>
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>

                <div className="text-center" style={{ marginTop: '5rem', backgroundColor: '#f9f9f9', padding: '3rem', borderRadius: 'var(--radius-md)' }}>
                    <h2 className="mb-4">Un projet sur mesure ?</h2>
                    <p className="mb-8" style={{ color: '#666' }}>
                        Chaque projet est unique. N'hésitez pas à me contacter pour un devis personnalisé adapté à vos besoins spécifiques.
                    </p>
                    <a href="/contact" className="btn btn-primary">Demander un devis</a>
                </div>
            </div>
        </div>
    );
};

export default Services;
