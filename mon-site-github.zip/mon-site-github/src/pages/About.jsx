import React from 'react';

const About = () => {
    return (
        <div className="animate-fade-in section">
            <div className="container">
                <div className="about-split">
                    <div className="order-2">
                        <h1 className="mb-4">À Propos</h1>
                        <p className="mb-4" style={{ fontSize: '1.1rem', color: '#555' }}>
                            Titulaire d'un Bac +3 en communication et événementiel, j'ai débuté mon parcours en me spécialisant dans l'organisation de mariages.
                        </p>
                        <p className="mb-4" style={{ fontSize: '1.1rem', color: '#555' }}>
                            C'est dans cet univers féérique que j'ai développé ma passion pour la communication visuelle : des plans de table aux marque-places, chaque détail compte pour créer une harmonie parfaite.
                        </p>
                        <p className="mb-4" style={{ fontSize: '1.1rem', color: '#555' }}>
                            Aujourd'hui, Polly Communication accompagne les particuliers et les professionnels dans la création de supports uniques et sur-mesure.
                        </p>
                    </div>
                    <div className="order-1">
                        <img
                            src="/about-workspace.jpg"
                            alt="Polly Communication"
                            style={{ borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)' }}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default About;
