export const services = [
  {
    category: "Visage",
    items: [
      { name: "Soin personnalisé", price: 55, duration: "1h", description: "Le soin personnalisé est adapté aux besoins de votre peau avec des produits cosmétiques ciblés qui agissent directement sur vos problématiques cutanées. ( peau déshydraté, grasse, mature…)" },
      { name: "Soin signature", price: 60, duration: "1h", description: "Le soin signature est un soin du visage où chaque geste de massage créé sur-mesure par votre esthéticienne Isabelle est ajusté aux besoins de votre peau." },
      { name: "Soin KOBIDO", price: 80, duration: "1h", highlight: true, badge: "Nouveau" },
      { name: "Soin KOBIDO", price: 70, duration: "45min", highlight: true, badge: "Nouveau" },
      { name: "Réhaussement de cils", price: 49 },
      { name: "Teinture de cils", price: 17 }
    ]
  },
  {
    category: "Abonnements Soins Visage",
    isSubscription: true,
    items: [
      { name: "3 soins visage", price: 148.50, description: "Réduction de -10%", originalPrice: 165 },
      { name: "5 soins visages", price: 233.50, description: "Réduction de -15%", originalPrice: 275 }
    ]
  },
  {
    category: "Abonnements KOBIDO",
    isSubscription: true,
    items: [
      { name: "4 séances + 1 offerte (1h)", price: 320, originalPrice: 400, description: "Cure Jeunesse & Éclat" },
      { name: "4 séances + 1 offerte (45min)", price: 280, originalPrice: 350, description: "Cure Express & Éclat" }
    ]
  },
  {
    category: "Épilations",
    items: [
      { name: "Demi-jambes", price: 16.5 },
      { name: "¾ jambes", price: 19 },
      { name: "Jambes complètes", price: 22 },
      { name: "Maillot ou Aisselles", price: 11 },
      { name: "Maillot Brésilien", price: 17 },
      { name: "Maillot intégral", price: 22 },
      { name: "Bras", price: 14 },
      { name: "Lèvre, sourcils ou menton", price: 7 },
      { name: "Epilation visage", price: 14 },
      { name: "Demi jambes + maillot + aisselles", price: 36 },
      { name: "Jambes complètes + ais + maillot", price: 42, description: "+9€ maillot intégral / +5€ maillot brésilien" }
    ]
  },
  {
    category: "Forfaits Épilations",
    isSubscription: true,
    items: [
      { name: "6 épilations demi-jambes", price: 84, originalPrice: 99, description: "-15%" },
      { name: "6 épilations jambes complètes", price: 112, originalPrice: 132, description: "-15%" },
      { name: "6 épilations aisselles ou maillot", price: 56, originalPrice: 66, description: "-15%" },
      { name: "6 épilations bras", price: 72, originalPrice: 84, description: "-15%" },
      { name: "6 épilations Lèvre ou sourcils", price: 35, originalPrice: 42, description: "-15%" },
      { name: "6 épilations visage", price: 71, originalPrice: 84, description: "-15%" },
      { name: "6 épilations DJ + ais + maillot", price: 183, originalPrice: 216, description: "-15%" },
      { name: "6 épilations JC + ais + maillot", price: 214, originalPrice: 252, description: "-15%" },
      { name: "Options maillot", price: "", description: "+45€ maillot intégral / +25€ maillot brésilien" }
    ]
  },
  {
    category: "Soins du Corps",
    items: [
      { name: "Modelage corporel relaxant", price: 57, duration: "1h" },
      { name: "Forfait 10 séances Modelage relaxant", price: 513, description: "1 modelage offert" },
      { name: "Modelage californien", price: 62, duration: "1h15" },
      { name: "Modelage dos", price: 30, duration: "30min" },
      { name: "Drainage lymphatique corps", price: 62, duration: "1h" },
      { name: "Gommage corps", price: 30 }
    ]
  },
  {
    category: "Mains & Pieds",
    items: [
      { name: "Manucure", price: 17 },
      { name: "Pose de vernis", price: 6 }
    ]
  },
  {
    category: "Radiofréquence Visage",
    note: "Uniquement à l'institut de Gouaix",
    description: "Aide à la réduction des rides et au raffermissement de l'ovale du visage",
    items: [
      { name: "1 séance", price: 49 },
      { name: "6 séances + 1 offerte", price: 294 },
      { name: "8 séances + 2 offertes", price: 392 }
    ]
  },
  {
    category: "Minceur par Cavitation",
    note: "Uniquement à l'institut de Gouaix",
    items: [
      { name: "Cavitation + Presso (1h, 1 zone) - 1 séance", price: 49 },
      { name: "Cavitation + Presso (1h, 1 zone) - 8 s. + 1 off.", price: 392, description: "Soit 39€ / séance" },
      { name: "Cavitation + Presso (1h, 1 zone) - 10 s. + 2 off.", price: 490 },
      { name: "Cavitation + RF + Presso (1h30, 1 zone) - 1 séance", price: 69 },
      { name: "Cavitation + RF + Presso (1h30, 1 zone) - 8 s. + 1 off.", price: 552 },
      { name: "Cavitation + RF + Presso (1h30, 1 zone) - 10 s. + 2 off.", price: 690 },
      { name: "Séance de Presso seule", price: 29 }
    ]
  }
];
