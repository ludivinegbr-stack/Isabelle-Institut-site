import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './sections/About';
import Services from './sections/Services';
import BookingForm from './sections/BookingForm';
import Testimonials from './sections/Testimonials';
import Profile from './sections/Profile';
import Institutes from './sections/Institutes';
import KobidoFeature from './sections/KobidoFeature';

function App() {
  return (
    <div className="app">
      <Header />
      <main>
        <Hero />
        <About />
        <Profile />
        <Institutes />
        <KobidoFeature />
        <Services />
        <Testimonials />
        <BookingForm />

        {/* Contact Section with Map */}
        <section id="contact" className="section bg-light">
          <div className="container">
            <div className="section-header text-center">
              <h2 className="section-title">Me trouver</h2>
              <p className="section-subtitle">Retrouvez-moi à mes deux adresses à Gouaix et Provins.</p>
            </div>
            <div className="maps-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem' }}>

              <div className="map-card">
                <h3 style={{ marginBottom: '1rem', textAlign: 'center', fontSize: '1.2rem', color: 'var(--color-primary)' }}>Institut Gouaix</h3>
                <p style={{ textAlign: 'center', marginBottom: '1rem', color: '#666' }}>12 grande rue, 77114 Gouaix</p>
                <div className="map-container" style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', boxShadow: 'var(--shadow-md)', height: '300px' }}>
                  <iframe
                    src="https://maps.google.com/maps?q=12%20grande%20rue%2077114%20gouaix&t=&z=15&ie=UTF8&iwloc=&output=embed"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  ></iframe>
                </div>
              </div>

              <div className="map-card">
                <h3 style={{ marginBottom: '1rem', textAlign: 'center', fontSize: '1.2rem', color: 'var(--color-primary)' }}>Institut Provins</h3>
                <p style={{ textAlign: 'center', marginBottom: '1rem', color: '#666' }}>6 bis route de bray, 77160 Provins</p>
                <div className="map-container" style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', boxShadow: 'var(--shadow-md)', height: '300px' }}>
                  <iframe
                    src="https://maps.google.com/maps?q=6%20bis%20route%20de%20bray%2077160%20Provins&t=&z=15&ie=UTF8&iwloc=&output=embed"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  ></iframe>
                </div>
              </div>

            </div>
          </div>
        </section>
      </main>

      <footer>
        <div className="container">
          <div className="brand" style={{ marginBottom: '1rem', color: 'var(--color-primary)' }}>ISABELLE INSTITUT</div>
          <p style={{ marginBottom: '2rem', color: '#999' }}>Votre escale beauté & bien-être.</p>
          <div style={{ fontSize: '0.9rem', color: '#666' }}>
            <p>&copy; {new Date().getFullYear()} Isabelle Institut. Tous droits réservés.</p>
            <p style={{ marginTop: '0.5rem' }}>Design & Développement par Antigravity</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
